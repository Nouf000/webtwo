<?php
// Connect to the databaseif
if(isset($_GET['value'])){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_value";


$value=$_GET['value'];
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
 {
    die("Connection failed: " . $conn->connect_error);
}

$q="INSERT INTO valuestable (var_value) VALUES ('$value')";

if ($conn->query($q)===true){
  
}
else{
	echo "Error: ". $q . "<br>" . $conn->error;
}


}
?>
<!DOCTYPE html>
<html>
<head>
	<title>My Page</title>
	<style>
		body {
			background-color: #f2f2f2;
			font-family: Arial, sans-serif;
		}
		h1 {
			color: #333;
			font-size: 36px;
			margin-top: 50px;
			text-align: center;
		}
		p {
			font-size: 24px;
			margin-top: 20px;
			text-align: center;
		}
	</style>
</head>
<body >
	<h1>Last saved value</h1>
	<p ><?php echo "Last value in database is <span style='font-weight:bold'>.$value.</span> "  ?></p>
</body>
</html>';
