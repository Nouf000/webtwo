-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10 أغسطس 2023 الساعة 17:21
-- إصدار الخادم: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_value`
--

-- --------------------------------------------------------

--
-- بنية الجدول `valuestable`
--

CREATE TABLE `valuestable` (
  `var_id` int(11) NOT NULL,
  `var_value` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `valuestable`
--

INSERT INTO `valuestable` (`var_id`, `var_value`, `created_at`) VALUES
(1, '', '2023-08-10 13:35:12'),
(2, '', '2023-08-10 13:35:32'),
(3, '', '2023-08-10 13:36:28'),
(4, '', '2023-08-10 13:38:55'),
(5, '', '2023-08-10 13:38:56'),
(6, '&#1605;&#1585;&#1581;&#1576;&#1575;', '2023-08-10 13:39:49'),
(7, '&#1605;&#1585;&#1581;&#1576;&#1575;', '2023-08-10 13:40:42'),
(8, '&#1605;&#1585;&#1581;&#1576;&#1575;', '2023-08-10 13:44:01'),
(9, 'gerfe', '2023-08-10 13:47:03'),
(10, '&#1606;&#1578;&#1576;&#1575;&#1578;&#1608;&#1606;&#1579;&#1575;&#1604;&#1576;&#1578;&#1575;&#1576;&#1589;&#1579;', '2023-08-10 13:48:08'),
(11, '&#1606;&#1578;&#1576;&#1575;&#1578;&#1608;&#1606;&#1579;&#1575;&#1604;&#1576;&#1578;&#1575;&#1576;&#1589;&#1579;', '2023-08-10 13:49:09'),
(12, '&#1587;&#1576;&#1604;&#1579;&#1602;&#1604;&#1602;&#1579;&#1604;', '2023-08-10 13:49:15'),
(13, '', '2023-08-10 13:52:53'),
(14, '&#1605;&#1585;&#1581;&#1576;&#1575;', '2023-08-10 13:53:23'),
(15, 'hjksdliwie', '2023-08-10 13:53:33'),
(16, 'bassff', '2023-08-10 13:55:49'),
(17, 'gggdg', '2023-08-10 13:59:12'),
(18, 'mku', '2023-08-10 14:02:50'),
(19, 'Hello', '2023-08-10 14:08:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `valuestable`
--
ALTER TABLE `valuestable`
  ADD PRIMARY KEY (`var_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `valuestable`
--
ALTER TABLE `valuestable`
  MODIFY `var_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
